<template lang="html">
  <div id="index">
    <banner/>
    <myMian class="mian"/>
  </div>
</template>

<script>
import Banner from '@/components/Banner'
import myMian from '@/components/Mymain'
export default {
  name:'Index',
  data(){
    return{

    }
  },
  components:{
    Banner,myMian
  }
}
</script>

<style lang="less" scoped>
.mian{
  margin-top: 2rem;
}
</style>
