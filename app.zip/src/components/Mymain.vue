<template lang="html">
  <div id="main">
    <h3 >健健科技APP下载</h3>
    <div class="main_box">
      <div class="main_01" @click="app">
        <div class="img"><img src="../assets/camera.png" alt=""></div>
        <div class="inline_block">
            <div >
              JJRC APP
            </div>
            <div >
               WiFi连接航拍实时操作，同步分享精彩瞬间。
            </div>
        </div>
      </div>
      <div class="main_01" @click="app2">
      <div class="img"><img src="../assets/jjrc.png" alt=""></div>
      <div class="inline_block">
          <div >
            JJRC TST(体验版)
          </div>
          <div >
            给你独特的视界，让你的航拍世界更精彩。
          </div>
      </div>
      </div>

    </div>
    <div class="footer">
      <h5>  <a href="http://www.jjrc.com/cn/content/cn_online-feedback.html" style="color:#666;">投诉</a></h5>
      <h5 style="color:#666;">© JJRC健健科技  版权所有</h5>
    </div>
  </div>
</template>

<script>
export default {
  name:'mymain',
  data(){
    return{
      s:'https://www.pgyer.com/eWhl'
    }
  },
  methods:{
    app(){
      let u = navigator.userAgent;
      let isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
      let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
      if (isAndroid&&!isiOS){
        window.location.href="https://www.pgyer.com/eWhl"
      }else {
        window.location.href="https://itunes.apple.com/cn/app/jjrc/id1168391406?mt=8"
      }
    },
    app2(){
      let u = navigator.userAgent;
      let isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
      let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
      if (isAndroid&&!isiOS){
          window.location.href="https://www.pgyer.com/ShzD"
      }else{
        window.location.href="https://itunes.apple.com/cn/app/jjrc-tst/id1268985821?mt=8"
      }
    }
  },
  created(){
      console.log(this);
      var u = navigator.userAgent;
      var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
      var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
      console.log('是否是Android：'+isAndroid);
      console.log('是否是iOS：'+isiOS);
  }
}
</script>

<style lang="less" scoped>
#main{
  width: 100%;
  min-height: 380px;
  h3{width: 96%;margin-left: 4%;}
  h5{text-align: center;margin: 5px;}
  div{margin: 5px auto;}
  .footer{
    margin-top: 7rem;
  }
}
.main_01{
  border: 1px solid #ccc;
  border-radius: 0.3rem;
}
.main_box{
  width: 94%;
  margin: 1rem  3%;
  padding: 1%;
  .inline_block{
    width: 70%;
    display: inline-block;
  }
  .img{
    width: 20%;
    height: 70px;
    display: inline-block;
  }
  img{
    width: 100%;
    height: 100%;
  }
}
</style>
